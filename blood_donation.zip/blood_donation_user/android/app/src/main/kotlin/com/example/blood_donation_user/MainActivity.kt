package com.example.blood_donation_user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
